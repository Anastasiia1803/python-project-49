from brain_games.cli import welcome_user
from brain_games.games.gcd import gcd


def main():
    welcome_user()
    gcd()


if __name__ == '__main__':
    main()
